const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '28122002Zain@',
    database: 'e_commerce'
});

db.connect(err => {
    if (err) throw err;
    console.log('MySQL connected...');
});

app.post('/add-to-cart', (req, res) => {
    const { userId, productId } = req.body;
    const query = 'INSERT INTO cart_items (user_id, product_id) VALUES (?, ?)';
    db.query(query, [userId, productId], (err, result) => {
        if (err) throw err;
        res.send('Product added to cart');
    });
});

app.post('/remove-from-cart', (req, res) => {
    const { userId, productId } = req.body;
    const query = 'DELETE FROM cart_items WHERE user_id = ? AND product_id = ?';
    db.query(query, [userId, productId], (err, result) => {
        if (err) throw err;
        res.send('Product removed from cart');
    });
});

app.post('/checkout', (req, res) => {
    const { firstName, lastName, phoneNumber, email, address } = req.body;
    const userQuery = 'INSERT INTO users (first_name, last_name, phone_number, email, address) VALUES (?, ?, ?, ?, ?)';
    db.query(userQuery, [firstName, lastName, phoneNumber, email, address], (err, userResult) => {
        if (err) throw err;
        const userId = userResult.insertId;
        const cartQuery = 'SELECT product_id FROM cart_items WHERE user_id = ?';
        db.query(cartQuery, [userId], (err, cartItems) => {
            if (err) throw err;
            const clearCartQuery = 'DELETE FROM cart_items WHERE user_id = ?';
            db.query(clearCartQuery, [userId], err => {
                if (err) throw err;
                res.send('Checkout complete');
            });
        });
    });
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
