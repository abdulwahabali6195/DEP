document.addEventListener('DOMContentLoaded', () => {
    fetchBlogs();

    document.getElementById('addBlogForm').addEventListener('submit', event => {
        event.preventDefault();
        addBlog();
    });
});

function fetchBlogs() {
    fetch('/blogs')
        .then(response => response.json())
        .then(blogs => {
            const blogsList = document.getElementById('blogsList');
            blogsList.innerHTML = '';
            blogs.forEach(blog => {
                const blogItem = document.createElement('div');
                blogItem.classList.add('blogItem');
                blogItem.innerHTML = `
                    <h2>${blog.title}</h2>
                    <p>${blog.content}</p>
                    <button onclick="deleteBlog(${blog.id})">Delete</button>
                    <button onclick="editBlog(${blog.id}, '${blog.title}', '${blog.content}')">Edit</button>
                `;
                blogsList.appendChild(blogItem);
            });
        });
}

function addBlog() {
    const title = document.getElementById('blogTitle').value;
    const content = document.getElementById('blogContent').value;

    fetch('/blogs', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title, content })
    })
    .then(() => {
        document.getElementById('blogTitle').value = '';
        document.getElementById('blogContent').value = '';
        fetchBlogs();
    });
}

function deleteBlog(id) {
    fetch(`/blogs/${id}`, {
        method: 'DELETE'
    })
    .then(() => {
        fetchBlogs();
    });
}

function editBlog(id, currentTitle, currentContent) {
    const newTitle = prompt('Enter new title:', currentTitle);
    const newContent = prompt('Enter new content:', currentContent);
    
    if (newTitle && newContent) {
        fetch(`/blogs/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title: newTitle, content: newContent })
        })
        .then(() => {
            fetchBlogs();
        });
    }
}
